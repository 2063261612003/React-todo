// import './App.css';
import TodoList from './components/TodoList';

// import ViewDetail from './componets/ViewDetail'
import './index.css'


function App() {
  return (
    
      <div >
        <TodoList />
      </div>
      
  );
}

export default App;
